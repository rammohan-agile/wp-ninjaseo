=== NinjaSEO by 500 Apps (SEO crawler, Page grader, AI Linkbot, Position tracker)===
Contributors:500 Apps 
Donate link: https://ninjaseo.com/
Tags: Ninjaseo, Wordpress seo, seo, seo plugin, xml sitemap, On Page Grader, seo optimization, webpage crawler, all in one Seo, yoastseo, yoast, scorely, best seo audit tool, link building,   
Requires at least: 3.0.1
Tested up to: 5.7
Stable tag: 0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Rank Higher in Search Engines with NinjaSEO, part of infinity app suite by 500apps. Get access to 30+apps for as low as $7.99. Trusted by 30,000+ users worldwide.

NinjaSEO is an exclusive page grader, web crawler plugin with built in AI Linkbot and Position tracker to help website owners find and fix pressing issues to improve seo performance.

About NinjaSEO

Beat the competition by analyzing SEO errors that harm search rankings of your page and fix them to improve visibility.

With NinjaSEO web crawler, perform a detailed site audit and identify broken links, sitemap issues, missing alt texts, image names and much more to improve overall website performance.

About 500apps

500apps is the world’s first all-in-one suite of 30+ apps catering to different industries to help businesses grow like the Fortune 500. NinjaSEO is a part of 500apps Infinity suite and helps you improve performance and SEO health of your website.

Website Crawler
Identify issues and make improvements

Issues
Get reports on all site-level errors such as broken links, server errors, etc.

URL Issues
Identify non-ASCII characters, character lengths, uppercasing, and underscores.

Crawl Depth
See how deep an URL is linked within your website and get information about it.

Links
Discover all internal and external links that are canonical and unique. Also, get the unique link percentage as a bird-eye view.

Redirects
Get information on redirects such as temporary, permanent, and the type like 301, 302, etc.

Indexability
Check the indexability of all links. 

Meta Titles & Descriptions
Analyze metadata such as tile and descriptions and check for target keywords, character lengths, etc.

Page Headers & Lengths
Identify the SEO health of all H1s and H2s of your website or page and fix them in easily.

Images
Get in-depth data on images such as image types, sizes, etc.

Alt Text
Check for the targeted keyword in the alt texts of all images.

X-Robot Tags
See all the directives issues through the HTTP header.

Word Length
Run a content analyzer to get the on-page world length.

Text-to-HTML Ratio
Calculate the code-to-text ratio and accordingly add or remove text or code from your page.

Last Modification
Discover when the last update was made on the page.

Loading time
Measure how fast your page is loading and accordingly reduce the size to make it load faster.

XML Sitemap
Find and add missing, non-indexable URLs from your XML sitemap.
Page Grader
Page Audit with Keyword
Analyze whether the given keyword is present at essential places such as page title and description, headers, URL, and much more.

Severity Check
Check the seriousness of the issues you are facing on your pages using the Grading indicators from Grade A to Grade F.

Learn and Fix Errors
Prioritize errors by studying the recommendation and follow the recommendations displayed to improve overall process and learning.

Page Grader

Get your page graded for 28 onsite issues and ensure page is SEO friendly.

AI Linkbot

Find high quality backlinks with our proprietary AI Linkbot. Enter the keyword you want to find links and our AI Linkbot will find backlinks that are ranking in search engine results pages along with author details making it easier for you to contact and build links to your website.

Know more about 500apps - https://vimeo.com/524251359
== Installation ==
Installing NinjaSEO WordPress plugin is easy. Head to the plugin and download it to start your journey of improving website performance. 

Here’s a 3 step guide to help you install and activate NinjaSEO plugin from your WordPress dashboard.

	1.Download NinjaSEO WordPress plugin from the dedicated plugins page.
	2.Activate NinjaSEO plugin from your Dashboard.
	3.Get started with NinjaSEO.

After Installation, see a NinjaSEO wizard in your dashboard to get a bird’s eye view of your entire website issues and ways to solve them.

== Frequently Asked Questions ==
= 1.How does NinjaSEO do when compared to its competitors? =

Unlike its competitors, NinjaSEO doesn't limit its users with feature restrictions. Once signed up, users can use NinjaSEO features to its limit. 

= 2.Does NinjaSEO offer any uptime guarantee? =

Online stability is critical for any business. For that reason, all 500apps services are hosted on Google and Amazon cloud to satisfy all demands and at every scale. We're pleased to announce that 500apps services are now backed up by a 99.99% uptime guarantee.

= 3.Can I cancel or upgrade my subscription at any time? =

NinjaSEO is powered by 500apps and plans start for the whole suite at $49 for a single user. You can upgrade for 5 users at just $99/user and add more users at $7.99 each. You can upgrade or cancel at any time.

= 4.How is a "user" defined? =

Any person with a unique 500apps username and login is a user, Each user's action while logged on can be tracked and recorded for optimal performance and analysis.

= 5.Will my subscription be renewed automatically? =

Yes, your subscription will be automatically renewed at your billing date unless there's a cancellation scenario.

= 6.Is my and my users' data safe? =

Yes, your privacy is of the utmost importance to us! Your data is stored on a secure cloud-based server, protected by 128-bit encryption and isn't shared with any third party services.

= 7.Who do I contact for additional questions? =

We always encourage you to ask all the questions you want to ensure we're right for you. Contact us at support@ninjaseo.com or support@500apps.com or call us anytime for more information or to share your feedback.

== Changelog ==
= 1.0 =
This version added our plugin

== Upgrade Notice == 

== Screenshots == 
1. '/assets/screenshot-1.png' 
2. '/assets/screenshot-2.png' 
3. '/assets/screenshot-3.png' 
4. '/assets/screenshot-4.png' 
4. '/assets/screenshot-5.png' 
